import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HomeComponent } from './home/home.component';
import { CardsComponent } from './cards/cards.component';
import { RoleComponent } from './role/role.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import {FormsModule} from '@angular/forms'
import{from} from 'rxjs';
import { UserComponent } from './user/user.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { EmpContentComponent } from './emp-content/emp-content.component';
import{EntityComponent} from'./entity/entity.component';
import { ClientformComponent } from './clientform/clientform.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { SampleComponent } from './sample/sample.component';
import { GstMasterComponent } from './gst-master/gst-master.component';
import { ClientBulkComponent } from './client-bulk/client-bulk.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReconComponent } from './recon/recon.component';
import { GstClientComponent } from './gst-client/gst-client.component';
import { UserMappingComponent } from './user-mapping/user-mapping.component';
import { RoleMapComponent } from './role-map/role-map.component';
import { PrivilegeMapComponent } from './privilege-map/privilege-map.component';
import { GroupMapComponent } from './group-map/group-map.component';
import { TableComponent } from './table/table.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewtableComponent } from './newtable/newtable.component';
import { ServiceComponent } from './service/service.component';
import { AboutUsComponent } from './aboutus/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { UserviewComponent } from './userview/userview.component';
import { MatSliderModule } from '@angular/material/slider';
import { FooterComponent } from './footer/footer.component';





@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    HomeComponent,
    CardsComponent,
    RoleComponent,
    LoginComponent,
    UserComponent,
    ResetpasswordComponent,
    EntityComponent,
    EmpContentComponent,
    ClientformComponent,
    CustomerProfileComponent,
    SampleComponent,
    GstMasterComponent,
    ClientBulkComponent,
    ReconComponent,
    GstClientComponent,
    UserMappingComponent,
    RoleMapComponent,
    PrivilegeMapComponent,
    GroupMapComponent,
    TableComponent,
    NewtableComponent,
    ServiceComponent,
    AboutUsComponent,
    ContactUsComponent,
    UserviewComponent,
    FooterComponent,
    

    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    BrowserAnimationsModule,
    MatSliderModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
