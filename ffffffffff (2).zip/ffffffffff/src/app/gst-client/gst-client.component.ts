import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';


@Component({
  selector: 'gst-client',
  templateUrl: './gst-client.component.html',
  styleUrls: ['./gst-client.component.css']
})
export class GstClientComponent implements OnInit {

  gstclient:FormGroup;
  constructor() { }

  ngOnInit(): void {
    this.gstclient = new FormGroup ({
      'cname':new FormControl(null,[Validators.required]),
      'pan': new FormControl(null,[Validators.required,Validators.pattern("^[A-Za-z]{5}[0-9]{4}[A-Za-z]$")]),
      'gst': new FormControl(null,[Validators.required,Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]),
    })
    
  }
  onsubmit(){
    if(this.gstclient.valid){
    console.log('Form Submitted')
  }
 else{
   console.log('validate all the fields')
 }
 }

}
