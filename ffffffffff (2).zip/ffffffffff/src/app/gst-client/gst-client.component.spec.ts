import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GstClientComponent } from './gst-client.component';

describe('GstClientComponent', () => {
  let component: GstClientComponent;
  let fixture: ComponentFixture<GstClientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GstClientComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GstClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
