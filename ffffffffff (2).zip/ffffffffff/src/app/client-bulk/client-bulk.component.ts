import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'client-bulk',
  templateUrl: './client-bulk.component.html',
  styleUrls: ['./client-bulk.component.css']
})
export class ClientBulkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
