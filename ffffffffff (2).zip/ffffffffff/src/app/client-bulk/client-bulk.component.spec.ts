import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientBulkComponent } from './client-bulk.component';

describe('ClientBulkComponent', () => {
  let component: ClientBulkComponent;
  let fixture: ComponentFixture<ClientBulkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientBulkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientBulkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
