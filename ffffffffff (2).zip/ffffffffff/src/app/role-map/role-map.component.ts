import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'role-map',
  templateUrl: './role-map.component.html',
  styleUrls: ['./role-map.component.css']
})
export class RoleMapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
