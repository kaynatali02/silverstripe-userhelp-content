import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'clientform',
  templateUrl: './clientform.component.html',
  styleUrls: ['./clientform.component.css']
})
export class ClientformComponent implements OnInit {
  myDate = Date.now();
  clientForm: FormGroup;
  constructor() { }

  ngOnInit(): void {
    this.clientForm = new FormGroup({
      'entyName': new FormControl(null,[Validators.required]),
      'entycode': new FormControl(null,[Validators.required]),
      'cliName': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9_ , . -]+[a-zA-Z0-9_ , . -]+[a-zA-Z0-9_ , . -]+")]),
      'gstinNo': new FormControl(null,[Validators.required,Validators.maxLength(15),Validators.pattern("^[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}[0-9]{1}[A-Za-z]{1}[0-9]{1}$")]),
      'panNo': new FormControl(null,[Validators.required,Validators.maxLength(10),Validators.pattern("^[A-Z]{5}[0-9]{4}[A-Z]$")]),
      'tanNo': new FormControl(null,[Validators.required,,Validators.maxLength(10),Validators.pattern("^[A-Z]{4}[0-9]{5}[A-Z]$")]),
      'cliTypeCode': new FormControl(null,[Validators.required, Validators.pattern('^[a-zA-Z ]*$')]),
      'cliCatgCode': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'ministryCode': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'miniStateCode': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'subMinistCode': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'ministNameothr': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9_ -]+[a-zA-Z0-9_ -]+[a-zA-Z0-9_ -]+")]),
      'refMark': new FormControl(null,[Validators.required]),
      'ainNo': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$")]),
      'paoCode': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'paoRegistNo': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'ddoCode': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'ddoRegistNo': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'dedPanno': new FormControl(null,[Validators.required,Validators.maxLength(10),Validators.pattern("^[A-Za-z]{5}[0-9]{4}[A-Za-z]$")]),
      'dedAddChange': new FormControl(null,[Validators.required, Validators.pattern('^[a-zA-Z ]*$')]),
      'dedAddChnageOn': new FormControl(null,[Validators.required]),
      'dedBranchDivision': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9_ -]+[a-zA-Z0-9_ -]+[a-zA-Z0-9_ -]+")]),
      'dedBankBranchCode': new FormControl(null,[Validators.required,,Validators.pattern('[0-9]{6}')]),
      'dedName': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'dedDesig': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9]+[a-zA-Z0-9]+[a-zA-Z0-9]+")]),
      'dedAdd1': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/ , . -]+")]),
      'dedAdd2': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/ , . -]+")]),
      'dedAdd3': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/, . -]+[a-zA-Z0-9/ ,. -]+")]),
      'dedAdd4': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/, . -]+[a-zA-Z0-9/ ,. -]+")]),
      'dedCountryCode':new FormControl(null,[Validators.required]),
      'dedStateCode': new FormControl(null,[Validators.required]),
      'dedCityCode': new FormControl(null,[Validators.required]),
      'dedPin': new FormControl(null,[Validators.required,Validators.maxLength(6),Validators.pattern('[0-9]{6}')]),
      'dedPhoneNo': new FormControl(null,[Validators.required,Validators.minLength(11),Validators.pattern("^[0-9]+[0-9]+[0-9]")]),
      'DED_MOBILENO': new FormControl(null,[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern('[6-9]\\d{9}')]),
      'dedEmailId': new FormControl(null,[Validators.required,Validators.email,Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$")]),
      'repAdd1': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/, . -]+[a-zA-Z0-9/ ,. -]+")]),
      'repAdd2': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/, . -]+[a-zA-Z0-9/ ,. -]+")]),
      'repAdd3': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/, . -]+[a-zA-Z0-9/ ,. -]+")]),
      'repAdd4': new FormControl(null,[Validators.required,Validators.pattern("^[a-zA-Z0-9/ , . -]+[a-zA-Z0-9/, . -]+[a-zA-Z0-9/ ,. -]+")]),
      'repCountryCode': new FormControl(null,[Validators.required]),
      'repStateCode': new FormControl(null,[Validators.required]),
      'repCityCode': new FormControl(null,[Validators.required]),
      'repPin': new FormControl(null,[Validators.required,Validators.maxLength(6),Validators.pattern('[0-9]{6}')]),
      'repPhoneNo': new FormControl(null,[Validators.required,Validators.minLength(11)]),
      'repMobileNO': new FormControl(null,[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern('[6-9]\\d{9}')]),
      'repEmailId': new FormControl(null,[Validators.required,Validators.email, Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$")]),
      'remark': new FormControl(null,[Validators.required]),
       }
      );
    }


  
  }