import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardsComponent } from './cards/cards.component';
import { ClientBulkComponent } from './client-bulk/client-bulk.component';
import { ClientformComponent } from './clientform/clientform.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { EmpContentComponent } from './emp-content/emp-content.component';
import { EntityComponent } from './entity/entity.component';
import { GstMasterComponent } from './gst-master/gst-master.component';
import { HomeComponent } from './home/home.component';
import { ReconComponent } from './recon/recon.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { RoleComponent } from './role/role.component';
import { SampleComponent } from './sample/sample.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { UserComponent } from './user/user.component';
import { GstClientComponent } from './gst-client/gst-client.component';
import { UserMappingComponent } from './user-mapping/user-mapping.component';
import { RoleMapComponent } from './role-map/role-map.component';
import { PrivilegeMapComponent } from './privilege-map/privilege-map.component';
import { GroupMapComponent } from './group-map/group-map.component';
import { TableComponent } from './table/table.component';
import { ServiceComponent } from './service/service.component';
import { AboutUsComponent } from './aboutus/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { UserviewComponent } from './userview/userview.component';
import { FooterComponent } from './footer/footer.component';

const routes: Routes = [
  {path: '',   redirectTo: '/table', pathMatch: 'full'},
  {path:'cards',component:CardsComponent},
  {path:'home',component:HomeComponent},
  {path:'sidebar',component:SidebarComponent},
  {path:'role',component:RoleComponent},
  {path:'login',component:RoleComponent},
  {path:'User',component:UserComponent},
  {path:'resetpassword',component:ResetpasswordComponent},
  {path:'entity',component:EntityComponent},
  {path:'clientform',component:ClientformComponent},
  {path:'emp-content',component:EmpContentComponent},
  {path:'sample',component:SampleComponent},
  {path:'gst-master',component:GstMasterComponent},
  {path:'customer-profile',component:CustomerProfileComponent},
  {path:'client-bulk',component:ClientBulkComponent},
  {path:'recon',component:ReconComponent},
  {path:'gst-client',component:GstClientComponent},
  {path:"table",component:TableComponent,children:[
    {path:'service',component:ServiceComponent},
    {path:'aboutus',component:AboutUsComponent},
    {path:'contact-us',component:ContactUsComponent},
    {path:'footer',component:FooterComponent}
  ]},
  {path:'user-mapping',component:UserMappingComponent,children:[
    {path:"role-map",component:RoleMapComponent},
    {path:"privilege-map",component:PrivilegeMapComponent},
    {path:"group-map",component:GroupMapComponent}
  ]},
{path:'userview',component:UserviewComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
