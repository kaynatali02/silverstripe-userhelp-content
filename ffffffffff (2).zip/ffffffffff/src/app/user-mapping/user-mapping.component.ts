import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-mapping',
  templateUrl: './user-mapping.component.html',
  styleUrls: ['./user-mapping.component.css']
})
export class UserMappingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
