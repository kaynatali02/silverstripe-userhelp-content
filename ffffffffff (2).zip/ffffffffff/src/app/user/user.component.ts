import { Component, OnInit } from '@angular/core';
import{ FormGroup,FormControl, Validators} from '@angular/forms'
@Component({
  selector: 'user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  userForm: FormGroup;

  constructor() { }

  ngOnInit(): void {
    this.userForm = new FormGroup({
      'userName': new FormControl(null,Validators.required),
      'shortName': new FormControl(null,Validators.required),
      'mobileNo': new FormControl(null,  [Validators.required, Validators.minLength(10),  
        Validators.maxLength(10),  
        Validators.pattern('^[0-9]*$')]),
      'userLogId': new FormControl( null,[Validators.required,Validators.email, Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$")]),
      'entityCode': new FormControl(null,Validators.required),
      'clientCode': new FormControl(null,Validators.required),
      'usrRoleId': new FormControl(null,Validators.required),
      'userLogPwd': new FormControl(null, [Validators.required,Validators.minLength(8) , Validators.pattern("^[a-zA-Z0-9._+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$")]),
      }
      );
    }

  saveUserForm(){
    
  }

}
