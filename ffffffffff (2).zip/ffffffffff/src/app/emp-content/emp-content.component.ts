import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-emp-content',
  templateUrl: './emp-content.component.html',
  styleUrls: ['./emp-content.component.css']
})
export class EmpContentComponent implements OnInit {
 
  @Input() regForm: FormGroup;
  @Input() relName = "";
  parentForm: any;
  public empContentForm: FormGroup;
  excel: FormControl = new FormControl(undefined);
  empList = [];
  list = [];
  empForm: any;
  formBuilder: any;
  empAccessRight: any;

  constructor() { }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
 

 
  buildForm(): void {
    this.empForm.addControl('empContent', this.empContentForm = this.formBuilder.group({

      excel: this.excel
    }));
    if (!this.empAccessRight.empContent.edit) {
      this.empForm.disable();
    }
  }

createTable() {

   let excelData = document.getElementById('excel')["value"];
    console.log("exceldata",excelData);

    //split into rows
   let excelRow = excelData.split(String.fromCharCode(10));
   console.log("excelrow", excelRow);

   //split rows into columns
   for (let i = 0; i < excelRow.length; i++) {
     excelRow[i] = excelRow[i].split(String.fromCharCode(9));
     console.log("col",excelRow[i]);
     }
  for (let i = 0; i < excelRow.length - 1; i++) {
  for (let j = 0; j < excelRow[i].length; j++) {
       if (excelRow[i][j].length != 0) {
        this.list = excelRow[i][j];


        console.log("val",this.list);
        }


       }

     }

   } }
  
