import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'entity',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.css']
})
export class EntityComponent implements OnInit {
  
  entityForm: FormGroup;

  constructor() { }

  ngOnInit(): void {
    this.entityForm = new FormGroup({
      'entity': new FormControl(null,Validators.required),
      'description': new FormControl(null,Validators.required),
      }
      );
    }

  saveEntityForm(){
    
  }

}
