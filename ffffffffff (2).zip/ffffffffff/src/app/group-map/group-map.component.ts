import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'group-map',
  templateUrl: './group-map.component.html',
  styleUrls: ['./group-map.component.css']
})
export class GroupMapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
