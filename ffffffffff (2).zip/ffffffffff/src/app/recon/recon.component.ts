import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';


@Component({
  selector: 'recon',
  templateUrl: './recon.component.html',
  styleUrls: ['./recon.component.css']
})
export class ReconComponent implements OnInit {
 
 Sum:any;
 Count:any;
 Max:any;
 Min:any;
 readyForNewInput= true;
 column;
 colm;
 rule;
  ItemsArray=[];
  ItemsArraytwo=[];
  sqlForm:FormGroup;
  value:any= '';
  numberGroup=[
  ['Sum','Count','Max','Min'],
  ['0','1','2','3'],                                                                   
  ['4','5','6','7'],
  ['8','9','.','='],
  ['!=','<','>','>='],
  ['<=','+','-','*'],
  ['/','%','(',')'],
  ['AND','OR','AC']
  ];

  tableGroup=[
  ['ENTITY_CODE','ENTITY_CODE'],
  ['STATE_CODE','CLIENT_STATE_CODE'],
  ['PANNO','VENDOR_PAN'],
  ['INVOICE_NUMBER','PARTY_BILL_NO'],
  ['INVOICE_DATE','  PARTY_BILL_DATE'],
  ['INVOICE_VALUE','TRANSACTION_AMOUNT_PAID'],
  ['TAXABLE_VALUE','TRANSACTION_BASIC_BILL_AMOUNT'],
  ['IGST_AMOUNT','TRANSACTION_IGST'],
  ['CGST_AMOUNT','TRANSACTION_CGST'],
  ['SGST_AMOUNT','TRANSACTION_SGST_UTGST'],
  ['CESS_AMOUNT',' TRANSACTION_CESS'] 

  ]
  Clear: string;
  onButtonPress(num){
    console.log(num)
  if(typeof num === 'string'){
    console.log('is a string');
    if(this.readyForNewInput)
    this.value= '' + num;
   else
  this.value += '' + num;
  this.readyForNewInput=false;
   if(num === 'AC'){
    this.value = ' ';
    this.readyForNewInput=true;
   
}
}
}
Back(){
  if(this.value !=" "){
    this.value=this.value.substr(" ",this.value.length-1)
}
}





  
  constructor() { }

  ngOnInit(): void {

    

    // this.ItemsArray = [
    //   "A.GSTR2_TRANS_ID",
    //   "A.JSON_TRANS_ID",
    //   "A.ENTITY_CODE",
    //   "A.CLIENT_CODE",
    //   "A.FILE_NAME",
    //   "A.GENERATION_DATE_TIME",
    //   "A.GSTIN",
    //   "A.PERIOD",
    //   "A.TRAN_TYPE",
    //   "A.COUNTER_PARTY_TIN",
    //   "A.COUNTER_PARTY_FILING_STATUS",
    //   "A.COUNTER_PARTY_NAME",
    //   "A.CHKSUM",
    //   "A.INVOICE_DATE",
    //   "A.INVOICE_NUMBER",
    //   "A.INVOICE_TYPE",
    //   "A.PLACE_OF_SUPPLY",
    //   "A.REVERSE_CHARGE",
    //   "A.INVOICE_VALUE",
    //   "A.UPLOADED_BY",
    //   "A.COUNTER_PARTY_FLAG",
    //   "A.DIFFERENTIAL_PERCENTAGE",
    //   "A.NOTE_DATE",
    //   "A.NOTE_NUMBER",
    //   "A.NOTE_TYPE",
    //   "A.P_GST",
    //   "A.REASON",
    //   "A.ORIGINAL_INV_DATE",
    //   "A.ORIGINAL_INV_NUMBER",
    //   "A.ORIGINAL_NOTE_DATE",
    //   "A.ORIGINAL_NOTE_NUMBER",
    //   "A.SERIAL_NUM",
    //   "A.RATE",
    //   "A.TAXABLE_VALUE",
    //   "A.IGST_AMOUNT",
    //   "A.CGST_AMOUNT",
    //   "A.SGST_AMOUNT",
    //   "A.CESS_AMOUNT",
    //   "A.TRAN_MONTH",
    //   "A.TCS_FLAG",
    //   "A.TCS_SUP_GSTIN",
    //   "A.TCS_SUP_NAME",
    //   "A.TCS_TRAN_AMOUNT",
    //   "A.TCS_GROSS_SUP",
    //   "A.TCS_GROSS_RET_SUP",
    //   "A.TCS_RET_SUP_R",
    //   "A.TCS_RET_SUP_U",
    //   "A.TCS_SUP_R",
    //   "A.TCS_SUP_U",
    //   "A.TDS_GSTIN_DEDUCTOR",
    //   "A.TDS_DEDUCTOR_NAME",
    //   "A.TDS_GSTIN_DEDUCTEE",
    //   "A.TDS_TRAN_AMOUNT",
    //   "A.ORIG_TRAN_MONTH",
    //   "A.TDSA_ORIG_GSTIN_DEDUCTEE",
    //   "A.TDSA_ORIG_TRAN_AMOUNT",
    //   "A.ISD_DOCUMENT_TYPE",
    //   "A.ISD_DOCUMENT_NUMBER",
    //   "A.ISD_ITC_ELIGIBILITY",
    //   "A.ISD_CESS",
    //   "A.ISD_DOCUMENT_DATE",
    //   "A.DUPLICATE_FLAG",
    //   "A.USER_SESSION_ID",
    //   "A.ACTIVE_FLAG",
    //   "A.CREATED_BY_DATE",
    //   "A.UPDATE_BY_DATE",
    //   "A.CREATED_BY",
    //   "A.UPDATED_BY",
    //   "A.SUPPLIER_FILING_DATE",
    //   "A.SUPPLIER_FILING_PERIOD",
    //   "A.SUPLIER_NOTE_TYPE",
    //   "A.ORIGINAL_NOTE_TYPE"
    //   ];

    //   this.ItemsArraytwo=[
    //     "B.VENDOR_TRANS_ID",
    //     "B.FILE_NAME",
    //     "B.GENERATION_DATE_TIME",
    //     "B.ENTITY_CODE",
    //     "B.CLIENT_CODE",
    //     "B.SOL_ID",
    //     "B.SET_ID",
    //     "B.ZONE_ID",
    //     "B.STATE_CODE",
    //     "B.TRAN_TYPE",
    //     "B.TRAN_REF_NO",
    //     "B.TRAN_REF_DATE",
    //     "B.EXTM_NUM",
    //     "B.CATG_CODE",
    //     "B.SUB_CATG_CODE",
    //     "B.DR_ACC_CODE",
    //     "B.DR_ACC_NAME",
    //     "B.CR_ACC_CODE",
    //     "B.CR_ACC_NAME",
    //     "B.BANK_SUPPLIER_GSTN_NO",
    //     "B.VENDOR_PAN_NUMBER",
    //     "B.GST_STATE_CODE",
    //     "B.SUPPLIER_GST_NAME",
    //     "B.SUPPLIER_GST_ADDRESS",
    //     "B.PARTYBILLNO",
    //     "B.PARTYBILLDATE",
    //     "B.PARTYBILLAMT",
    //     "B.TAXABLE_AMT",
    //     "B.GST_RATE",
    //     "B.CGST_AMT",
    //     "B.SGST_UTGST_AMT",
    //     "B.IGST_AMT",
    //     "B.CESS_AMT",
    //     "B.PLACE_OF_SUPPLY",
    //     "B.REVERSE_CHARGE",
    //     "B.INPUT_TAX_CREDIT",
    //     "B.D_RCM_ITC_INP_CGST",
    //     "B.D_RCM_ITC_INP_SGST",
    //     "B.D_RCM_ITC_INP_IGST",
    //     "B.D_ITC_INP_CGST",
    //     "B.D_ITC_INP_SGST",
    //     "B.D_ITC_INP_IGST",
    //     "B.ITC_NOT_ALLWD50",
    //     "B.ITC_INEL100CSGST",
    //     "B.ITC_INEL100IGST",
    //     "B.REMARKS",
    //     "B.SECTION_CODE",
    //     "B.TDS_AMT",
    //     "B.HSN_SAC_CODE",
    //     "B.HSN_SAC_DESC",
    //     "B.OVERSEAS_SEZ_SUPPLY",
    //     "B.FAMS_EMP_ID",
    //     "B.CREATION_DATE",
    //     "B.PENALTY",
    //     "B.AMC_REVERSAL_FLAG",
    //     "B.AMC_START",
    //     "B.AMC_END",
    //     "B.CR_TRAN_REF_NO",
    //     "B.CR_TRAN_REF_DATE",
    //     "B.CR_TRAN_REF_AMT",
    //     "B.DR_TRAN_REF_NO",
    //     "B.DR_TRAN_REF_DATE",
    //     "B.DR_TRAN_REF_AMT",
    //     "B.CGST_GST_TDS_RATE",
    //     "B.SGST_GST_TDS_RATE",
    //     "B.IGST_GST_TDS_RATE",
    //     "B.CGST_GST_TDS_AMT",
    //     "B.SGST_GST_TDS_AMT",
    //     "B.IGST_GST_TDS_AMT",
    //     "B.TRAN_ID",
    //     "B.TRAN_DATE",
    //     "B.QUANTITY",
    //     "B.PURCHASE_VALUE",
    //     "B.FILLER1",
    //     "B.ACTIVE_FLAG",
    //     "B.CREATED_BY_DATE",
    //     "B.UPDATE_BY_DATE",
    //     "B.CREATED_BY",
    //     "B.UPDATED_BY"
    //     ];
        this.sqlForm = new FormGroup({
          'display':new FormControl()
          })    
  }

}
