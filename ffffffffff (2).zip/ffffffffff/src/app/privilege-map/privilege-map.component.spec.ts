import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivilegeMapComponent } from './privilege-map.component';

describe('PrivilegeMapComponent', () => {
  let component: PrivilegeMapComponent;
  let fixture: ComponentFixture<PrivilegeMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrivilegeMapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivilegeMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
