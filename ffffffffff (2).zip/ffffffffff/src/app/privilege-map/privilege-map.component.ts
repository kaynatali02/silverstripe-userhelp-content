import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'privilege-map',
  templateUrl: './privilege-map.component.html',
  styleUrls: ['./privilege-map.component.css']
})
export class PrivilegeMapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
