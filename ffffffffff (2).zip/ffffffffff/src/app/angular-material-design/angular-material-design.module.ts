import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewTableComponent} from './new-table/new-table.component';
import { MatSliderModule } from '@angular/material/slider';



@NgModule({
  declarations: [NewTableComponent],
  imports: [
    CommonModule,
    MatSliderModule
  ]
})
export class AngularMaterialDesignModule { }
